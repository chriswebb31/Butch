<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="sdv" tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="stardewValley.png" trans="223431" width="400" height="1264"/>
</tileset>
