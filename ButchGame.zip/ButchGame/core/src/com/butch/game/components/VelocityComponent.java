package com.butch.game.components;

import com.badlogic.ashley.core.Component;

public class VelocityComponent implements Component {
    private float x = 0.0f;
    private float y = 0.0f;
}
